import React, { useState, useEffect, useRef } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import './SideMenu.css'

const NAV_ITEMS = {
  compositor: [
    { to: '/descoberta',  icon: '⊞', label: 'Descoberta'      },
    { to: '/dashboard',   icon: '◈', label: 'Dashboard'       },
    { to: '/obras',       icon: '♫', label: 'Minhas obras'    },
    { to: '/obras/nova',  icon: '♪', label: 'Nova obra'       },
    { to: '/saques',      icon: '◎', label: 'Saques (PayPal)' },
    { to: '/ofertas',     icon: '✉', label: 'Ofertas'         },
  ],
  interprete: [
    { to: '/descoberta',  icon: '⊞', label: 'Descoberta'      },
    { to: '/compras',     icon: '◉', label: 'Compras'         },
    { to: '/ofertas',     icon: '✉', label: 'Ofertas'         },
  ],
  administrador: [
    { to: '/descoberta',  icon: '⊞', label: 'Descoberta'      },
    { to: '/admin',       icon: '▦', label: 'Painel admin'    },
  ],
}

function useIsMobile() {
  const [m, setM] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)
  useEffect(() => {
    function h() { setM(window.innerWidth < 768) }
    window.addEventListener('resize', h)
    return () => window.removeEventListener('resize', h)
  }, [])
  return m
}

function UserMenu({ perfil, collapsed }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  const navigate = useNavigate()
  const { signOut } = useAuth()

  useEffect(() => {
    function handle(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [])

  if (!perfil) return null
  const iniciais = perfil.nome?.split(' ').slice(0,2).map(n=>n[0]).join('').toUpperCase() ?? '?'

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <div className="sidebar-user-btn" onClick={() => setOpen(o => !o)}>
        <div className="sidebar-avatar">
          {perfil.avatar_url ? <img src={perfil.avatar_url} alt={perfil.nome} /> : iniciais}
        </div>
        {!collapsed && (
          <>
            <div className="sidebar-user-info">
              <span className="sidebar-user-nome">{perfil.nome_artistico || perfil.nome}</span>
              <span className="sidebar-user-role">{perfil.role}</span>
            </div>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 'auto' }}>{open ? '▴' : '▾'}</span>
          </>
        )}
      </div>
      {open && (
        <div className="sidebar-user-dropdown">
          <button className="sidebar-user-item" onClick={() => { setOpen(false); navigate('/perfil/editar') }}>
            <span>✎</span> Editar informações
          </button>
          <div className="sidebar-user-divider" />
          <button className="sidebar-user-item sidebar-user-item-danger" onClick={() => { setOpen(false); signOut() }}>
            <span>⏻</span> Sair da conta
          </button>
        </div>
      )}
    </div>
  )
}

export default function SideMenu({ onCollapse }) {
  const isMobile = useIsMobile()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { perfil, signOut } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => { onCollapse?.(isMobile ? true : collapsed) }, [collapsed, isMobile])
  useEffect(() => { setMobileOpen(false) }, [location.pathname])  // fecha drawer ao navegar

  const role = perfil?.role ?? 'compositor'
  const items = NAV_ITEMS[role] ?? NAV_ITEMS.compositor

  // ── MOBILE: hamburger + drawer ──────────────────────
  if (isMobile) {
    return (
      <>
        <button
          className="mobile-hamburger"
          onClick={() => setMobileOpen(true)}
          aria-label="Abrir menu"
        >
          <span /><span /><span />
        </button>

        {mobileOpen && (
          <div
            className="mobile-drawer-backdrop"
            onClick={() => setMobileOpen(false)}
          />
        )}

        <aside className={`sidebar mobile-drawer ${mobileOpen ? 'mobile-drawer-open' : ''}`}>
          <div className="sidebar-header">
            <button className="sidebar-logo-btn" onClick={() => { navigate('/descoberta'); setMobileOpen(false) }}>
              PITCH.ME
            </button>
            <button
              className="sidebar-toggle"
              onClick={() => setMobileOpen(false)}
              aria-label="Fechar menu"
            >×</button>
          </div>

          <nav className="sidebar-nav">
            {items.map(({ to, icon, label }) => (
              <NavLink key={to} to={to}
                className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
                <span className="sidebar-icon">{icon}</span>
                <span>{label}</span>
              </NavLink>
            ))}

            <div style={{ height: 1, background: 'var(--border)', margin: '8px 4px' }} />

            <NavLink to="/perfil/editar"
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <span className="sidebar-icon">✎</span>
              <span>Editar informações</span>
            </NavLink>

            <button
              className="sidebar-link"
              onClick={() => signOut()}
              style={{ color: 'var(--error)' }}>
              <span className="sidebar-icon">⏻</span>
              <span>Sair da conta</span>
            </button>
          </nav>

          <div className="sidebar-footer">
            <UserMenu perfil={perfil} collapsed={false} />
          </div>
        </aside>
      </>
    )
  }

  // ── DESKTOP: sidebar fixa ─────────────────────────
  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        {!collapsed && (
          <button className="sidebar-logo-btn" onClick={() => navigate('/descoberta')}>
            PITCH.ME
          </button>
        )}
        <button className="sidebar-toggle" onClick={() => setCollapsed(c => !c)}>
          {collapsed ? '›' : '‹'}
        </button>
      </div>

      <nav className="sidebar-nav">
        {items.map(({ to, icon, label }) => (
          <NavLink key={to} to={to}
            className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            title={collapsed ? label : undefined}>
            <span className="sidebar-icon">{icon}</span>
            {!collapsed && <span>{label}</span>}
          </NavLink>
        ))}

        <div style={{ height: 1, background: 'var(--border)', margin: '8px 4px' }} />

        <NavLink to="/perfil/editar"
          className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
          title={collapsed ? 'Editar informações' : undefined}>
          <span className="sidebar-icon">✎</span>
          {!collapsed && <span>Editar informações</span>}
        </NavLink>

        <button
          className="sidebar-link"
          onClick={() => signOut()}
          title={collapsed ? 'Sair da conta' : undefined}
          style={{ color: 'var(--error)' }}>
          <span className="sidebar-icon">⏻</span>
          {!collapsed && <span>Sair da conta</span>}
        </button>
      </nav>

      <div className="sidebar-footer">
        <UserMenu perfil={perfil} collapsed={collapsed} />
      </div>
    </aside>
  )
}
