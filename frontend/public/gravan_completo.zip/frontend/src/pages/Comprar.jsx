import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../lib/api'

function fmt(cents) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format((cents ?? 0) / 100)
}

const METODOS = [
  { id: 'pix',     icone: '◎', label: 'PIX',              desc: 'Aprovação imediata · sem taxas extras' },
  { id: 'credito', icone: '▪', label: 'Cartão de Crédito', desc: 'Visa, Mastercard, Elo, Amex' },
  { id: 'debito',  icone: '▫', label: 'Cartão de Débito',  desc: 'Débito à vista' },
]

export default function Comprar() {
  const { obraId } = useParams()
  const navigate   = useNavigate()

  const [obra,    setObra]    = useState(null)
  const [metodo,  setMetodo]  = useState('credito')
  const [loading, setLoading] = useState(true)
  const [pagando, setPagando] = useState(false)
  const [erro,    setErro]    = useState('')

  useEffect(() => {
    api.get(`/catalogo/${obraId}`)
      .then(setObra)
      .catch(() => navigate('/descoberta'))
      .finally(() => setLoading(false))
  }, [obraId])

  async function confirmar() {
    setPagando(true); setErro('')
    try {
      const { checkout_url } = await api.post('/stripe/checkout', { obra_id: obraId, metodo })
      window.location.href = checkout_url
    } catch (e) {
      setErro(e.message)
      setPagando(false)
    }
  }

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 400 }}>
      <p style={{ color: 'var(--text-muted)' }}>Carregando…</p>
    </div>
  )
  if (!obra) return null

  return (
    <div style={{ padding: 32, maxWidth: 560 }}>
      <button
        onClick={() => navigate('/descoberta')}
        style={{ background: 'none', border: 'none', color: 'var(--brand)', cursor: 'pointer', fontSize: 14, padding: 0, marginBottom: 20 }}
      >
        ← Voltar ao catálogo
      </button>

      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>Finalizar licença</h1>
      <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>Licenciamento de composição musical</p>

      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 12,
            background: 'linear-gradient(135deg, #BE123C, #09090B)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 24, flexShrink: 0,
          }}>♪</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 17 }}>{obra.nome}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>
              {obra.titular_nome}
              {obra.genero && ` · ${obra.genero}`}
            </div>
          </div>
        </div>

        {obra.coautores?.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>Compositores</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {obra.coautores.map(c => (
                <span key={c.perfil_id} style={{
                  background: 'var(--brand-light)', color: 'var(--brand)',
                  padding: '3px 10px', borderRadius: 99, fontSize: 12,
                }}>
                  {c.nome}
                </span>
              ))}
            </div>
          </div>
        )}

        <div style={{
          display: 'flex', justifyContent: 'space-between',
          fontWeight: 700, fontSize: 22,
          borderTop: '1px solid var(--border)', paddingTop: 16, marginTop: 8,
        }}>
          <span>Total</span>
          <span style={{ color: 'var(--brand)' }}>{fmt(obra.preco_cents)}</span>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', letterSpacing: 1, marginBottom: 14 }}>
          MÉTODO DE PAGAMENTO
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {METODOS.map(m => (
            <label key={m.id} style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '13px 16px', borderRadius: 'var(--radius-md)',
              border: `2px solid ${metodo === m.id ? 'var(--brand)' : 'var(--border)'}`,
              background: metodo === m.id ? 'var(--brand-light)' : 'var(--surface)',
              cursor: 'pointer', transition: 'all .15s',
            }}>
              <input
                type="radio" name="metodo" value={m.id}
                checked={metodo === m.id}
                onChange={() => setMetodo(m.id)}
                style={{ accentColor: 'var(--brand)', width: 16, height: 16 }}
              />
              <span style={{ fontSize: 22, color: metodo === m.id ? 'var(--brand)' : 'var(--text-muted)' }}>
                {m.icone}
              </span>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{m.label}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{m.desc}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      {erro && (
        <div className="card" style={{ background: 'var(--error-bg)', border: '1px solid var(--error)', marginBottom: 16 }}>
          <p style={{ color: 'var(--error)', fontSize: 14 }}>{erro}</p>
        </div>
      )}

      <button
        className="btn btn-primary"
        style={{ width: '100%', justifyContent: 'center', fontSize: 16, padding: '14px 20px' }}
        onClick={confirmar}
        disabled={pagando}
      >
        {pagando ? 'Redirecionando…' : `🔒 Pagar com Stripe · ${fmt(obra.preco_cents)}`}
      </button>

      <div style={{
        marginTop: 14, padding: 12,
        background: 'var(--surface-2)', borderRadius: 8,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <span style={{ fontSize: 16 }}>🔐</span>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: 0 }}>
          Você será redirecionado para a página segura do Stripe para concluir o pagamento.
        </p>
      </div>
    </div>
  )
}
