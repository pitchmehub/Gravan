import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

const API_URL = import.meta.env.VITE_API_URL

export default function Landing() {
  const [showContato, setShowContato] = useState(false)
  const [stats, setStats] = useState(null)
  const { user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    let mounted = true
    async function loadStats() {
      try {
        const res = await fetch(`${API_URL}/catalogo/stats/public`)
        if (!res.ok) throw new Error('fail')
        const data = await res.json()
        if (!mounted) return
        setStats({
          obras: data.obras || 0,
          compositores: data.compositores || 0,
          totalPago: data.total_pago || 0,
        })
      } catch {
        if (mounted) setStats({ obras: 0, compositores: 0, totalPago: 0 })
      }
    }
    loadStats()
    return () => { mounted = false }
  }, [])

  const handleCTA = () => {
    if (user) {
      navigate('/dashboard')
    } else {
      navigate('/login')
    }
  }

  function formatNumber(n) {
    if (n < 1000) return String(n)
    if (n < 10000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k'
    return Math.round(n / 1000) + 'k'
  }

  function formatBRL(n) {
    if (!n || n < 1) return 'R$ 0'
    if (n < 1000) return `R$ ${Math.round(n)}`
    if (n < 1_000_000) return `R$ ${(n / 1000).toFixed(1).replace(/\.0$/, '')}k`
    return `R$ ${(n / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`
  }

  return (
    <div className="landing-v1">
      {/* Navigation */}
      <nav className="nav-minimal" data-testid="landing-nav">
        <div className="nav-container">
          <a href="#" className="logo" data-testid="logo">
            <span className="logo-mark">●</span> Pitch.me
          </a>
          <div className="nav-center">
            <a href="#como-funciona" data-testid="nav-como-funciona">Como Funciona</a>
            <a href="#recursos" data-testid="nav-recursos">Recursos</a>
            <a href="#precos" data-testid="nav-precos">Preços</a>
          </div>
          <div className="nav-actions">
            {user ? (
              <button
                className="btn-accent"
                onClick={() => navigate('/dashboard')}
                data-testid="nav-btn-dashboard"
              >
                Dashboard →
              </button>
            ) : (
              <button
                className="btn-accent"
                onClick={() => navigate('/login')}
                data-testid="nav-btn-entrar"
              >
                Entrar
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero" data-testid="hero-section">
        <div className="hero-grid">
          <div className="hero-text">
            <div className="eyebrow">
              <span className="dot-rec" /> MARKETPLACE DE OBRAS MUSICAIS
            </div>
            <h1 className="hero-title">
              Venda suas <br />
              <span className="italic-light">obras musicais</span> <br />
              como nunca antes.
            </h1>
            <p className="hero-subtitle">
              O marketplace que conecta compositores e compradores com
              transparência, segurança e pagamento instantâneo.
            </p>
            <div className="hero-cta-row">
              <button
                className="btn-primary"
                onClick={handleCTA}
                data-testid="hero-cta-comecar"
              >
                ▶ Começar Agora
              </button>
              <a href="#como-funciona" className="btn-ghost" data-testid="hero-cta-saiba-mais">
                Saiba mais →
              </a>
            </div>
            <div className="hero-meta">
              <div data-testid="stat-compositores">
                <strong>{stats ? formatNumber(stats.compositores) : '—'}</strong>
                <span>{stats && stats.compositores === 1 ? 'Compositor' : 'Compositores'}</span>
              </div>
              <div data-testid="stat-obras">
                <strong>{stats ? formatNumber(stats.obras) : '—'}</strong>
                <span>{stats && stats.obras === 1 ? 'Obra publicada' : 'Obras publicadas'}</span>
              </div>
              <div data-testid="stat-pagos">
                <strong>{stats ? formatBRL(stats.totalPago) : '—'}</strong>
                <span>Pagos a compositores</span>
              </div>
            </div>
          </div>
          <div className="hero-media">
            <img
              src="https://images.pexels.com/photos/32725048/pexels-photo-32725048.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900"
              alt="Equipamento de estúdio musical"
              loading="eager"
            />
            <div className="hero-media-label">
              <span className="dot-rec" /> EM GRAVAÇÃO · 04:37
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="section-block" id="como-funciona" data-testid="section-como-funciona">
        <div className="block-header">
          <span className="section-index">01</span>
          <h2 className="section-title">Como Funciona</h2>
          <p className="section-lead">
            Dois fluxos simples. Uma plataforma construída para todos os lados do palco.
          </p>
        </div>
        <div className="grid-two">
          <div className="grid-col" data-testid="card-compositores">
            <div className="col-head">
              <span className="col-label">PARA COMPOSITORES</span>
              <h3>Transforme sua arte <br />em receita recorrente.</h3>
            </div>
            <ol className="step-list">
              <li>
                <span className="step-num">1</span>
                <div>
                  <strong>Cadastre-se em 2 minutos</strong>
                  <p>Crie sua conta, configure seu perfil e dados bancários.</p>
                </div>
              </li>
              <li>
                <span className="step-num">2</span>
                <div>
                  <strong>Faça upload do seu MP3</strong>
                  <p>Arquivos até 10MB. Metadados, coautoria e licenças claras.</p>
                </div>
              </li>
              <li>
                <span className="step-num">3</span>
                <div>
                  <strong>Receba a cada venda</strong>
                  <p>Split automático, relatórios e pagamentos via Stripe/PayPal.</p>
                </div>
              </li>
            </ol>
          </div>
          <div className="grid-col grid-col-dark" data-testid="card-compradores">
            <div className="col-head">
              <span className="col-label">PARA COMPRADORES</span>
              <h3>Descubra obras exclusivas <br />e licencie sem fricção.</h3>
            </div>
            <ol className="step-list">
              <li>
                <span className="step-num">1</span>
                <div>
                  <strong>Explore o catálogo</strong>
                  <p>Busque por gênero, BPM, humor e tipo de licença.</p>
                </div>
              </li>
              <li>
                <span className="step-num">2</span>
                <div>
                  <strong>Compre com segurança</strong>
                  <p>Checkout criptografado e contrato gerado automaticamente.</p>
                </div>
              </li>
              <li>
                <span className="step-num">3</span>
                <div>
                  <strong>Use onde precisar</strong>
                  <p>Download instantâneo e licença rastreável.</p>
                </div>
              </li>
            </ol>
          </div>
        </div>
      </section>

      {/* Recursos */}
      <section className="section-block section-features" id="recursos" data-testid="section-recursos">
        <div className="block-header">
          <span className="section-index">02</span>
          <h2 className="section-title">Recursos construídos para escalar.</h2>
        </div>
        <div className="features-grid">
          <div className="feature-cell" data-testid="feature-uploads">
            <div className="feature-label">01 / UPLOAD</div>
            <h4>MP3 até 10MB</h4>
            <p>Upload rápido, validação de metadata e preview instantâneo no player.</p>
          </div>
          <div className="feature-cell" data-testid="feature-pagamento">
            <div className="feature-label">02 / PAGAMENTOS</div>
            <h4>Stripe & PayPal</h4>
            <p>Checkout em BRL e USD. Repasse automático e relatórios fiscais.</p>
          </div>
          <div className="feature-cell" data-testid="feature-seguranca">
            <div className="feature-label">03 / SEGURANÇA</div>
            <h4>Criptografia de ponta</h4>
            <p>CPF/RG criptografados, RLS no banco e logs de auditoria em tempo real.</p>
          </div>
          <div className="feature-cell" data-testid="feature-coautoria">
            <div className="feature-label">04 / COAUTORIA</div>
            <h4>Split automático</h4>
            <p>Divida receitas com coautores direto no cadastro da obra.</p>
          </div>
          <div className="feature-cell" data-testid="feature-analytics">
            <div className="feature-label">05 / ANALYTICS</div>
            <h4>Dashboard completo</h4>
            <p>Vendas, plays, origem do tráfego e performance por obra.</p>
          </div>
          <div className="feature-cell" data-testid="feature-suporte">
            <div className="feature-label">06 / SUPORTE</div>
            <h4>Humano, quando precisa</h4>
            <p>Equipe dedicada e base de conhecimento aberta 24/7.</p>
          </div>
        </div>
      </section>

      {/* Manifesto editorial (sem depoimentos fake) */}
      <section className="testimonial" data-testid="section-manifesto">
        <div className="testimonial-inner">
          <span className="quote-mark">"</span>
          <blockquote className="testimonial-quote">
            Feito por quem respeita a obra.<br />
            <span className="italic-light">Pago por quem respeita o autor.</span>
          </blockquote>
          <div className="testimonial-author">
            <div>
              <strong>Pitch.me</strong>
              <span>Marketplace independente de composições musicais</span>
            </div>
          </div>
        </div>
      </section>

      {/* Preços / Stats */}
      <section className="section-block" id="precos" data-testid="section-precos">
        <div className="block-header">
          <span className="section-index">03</span>
          <h2 className="section-title">Preço honesto. Sem pegadinhas.</h2>
          <p className="section-lead">
            Sem mensalidade. Você só paga quando vende.
          </p>
        </div>
        <div className="pricing-grid">
          <div className="price-cell" data-testid="plan-basico">
            <div className="price-label">PLANO BÁSICO</div>
            <div className="price-value">Grátis</div>
            <ul className="price-list">
              <li>Upload ilimitado</li>
              <li>Taxa de 12% por venda</li>
              <li>Pagamento em até 7 dias</li>
              <li>Suporte por e-mail</li>
            </ul>
            <button className="btn-ghost full" onClick={handleCTA}>
              Começar grátis →
            </button>
          </div>
          <div className="price-cell price-cell-feature" data-testid="plan-pro">
            <div className="price-ribbon">MAIS POPULAR</div>
            <div className="price-label">PLANO PRO</div>
            <div className="price-value">R$ 49<small>/mês</small></div>
            <ul className="price-list">
              <li>Tudo do Básico</li>
              <li>Taxa reduzida de 7% por venda</li>
              <li>Pagamento em 24h</li>
              <li>Analytics avançado</li>
              <li>Suporte prioritário</li>
            </ul>
            <button className="btn-primary full" onClick={handleCTA} data-testid="plan-pro-cta">
              Assinar Pro ▶
            </button>
          </div>
        </div>
      </section>

      {/* Footer massivo */}
      <footer className="footer-massive" data-testid="footer">
        <div className="footer-top">
          <div className="footer-links-row">
            <div>
              <h4>Plataforma</h4>
              <a href="#como-funciona">Como Funciona</a>
              <a href="#recursos">Recursos</a>
              <a href="#precos">Preços</a>
              <a href="/login">Login</a>
            </div>
            <div>
              <h4>Legal</h4>
              <a href="#termos">Termos de Uso</a>
              <a href="#privacidade">Privacidade</a>
              <a href="#contrato">Contratos</a>
            </div>
            <div>
              <h4>Contato</h4>
              <a href="mailto:contato@pitchme.com">contato@pitchme.com</a>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault()
                  setShowContato(true)
                }}
                data-testid="footer-fale-conosco"
              >
                Fale Conosco
              </a>
            </div>
          </div>
          <div className="footer-cta">
            <h2>Comece agora.</h2>
            <button
              className="btn-primary footer-btn"
              onClick={handleCTA}
              data-testid="footer-cta-comecar"
            >
              ▶ Criar conta grátis
            </button>
          </div>
        </div>
        <div className="footer-wordmark">PITCH.ME</div>
        <div className="footer-bottom">
          <span>© 2025 Pitch.me — Todos os direitos reservados.</span>
          <span>Feito com precisão para compositores.</span>
        </div>
      </footer>

      {showContato && (
        <div className="modal-backdrop" onClick={() => setShowContato(false)} data-testid="contato-modal">
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <h3>Fale Conosco</h3>
            <p>Envie um e-mail para <strong>contato@pitchme.com</strong> ou responda este modal em breve.</p>
            <button className="btn-primary" onClick={() => setShowContato(false)} data-testid="contato-fechar">
              Fechar
            </button>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');

        :root {
          --bg: #FFFFFF;
          --surface: #F4F4F5;
          --text: #09090B;
          --muted: #71717A;
          --accent: #E11D48;
          --border: #E4E4E7;
          --ink: #09090B;
        }

        .landing-v1 {
          background: var(--bg);
          color: var(--text);
          min-height: 100vh;
          font-family: 'IBM Plex Sans', system-ui, -apple-system, sans-serif;
          line-height: 1.5;
        }

        .landing-v1 * { box-sizing: border-box; }

        .landing-v1 h1, .landing-v1 h2, .landing-v1 h3, .landing-v1 h4 {
          font-family: 'Space Grotesk', 'Inter', sans-serif;
          letter-spacing: -0.02em;
          font-weight: 700;
          margin: 0;
        }

        .italic-light {
          font-style: italic;
          font-weight: 300;
        }

        /* ===================== NAV ===================== */
        .nav-minimal {
          position: sticky;
          top: 0;
          background: #FFFFFF;
          border-bottom: 1px solid var(--border);
          z-index: 100;
        }
        .nav-container {
          max-width: 1280px;
          margin: 0 auto;
          padding: 18px 32px;
          display: grid;
          grid-template-columns: 1fr auto 1fr;
          align-items: center;
          gap: 24px;
        }
        .logo {
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 700;
          font-size: 20px;
          color: var(--text);
          text-decoration: none;
          letter-spacing: -0.02em;
          display: inline-flex;
          align-items: center;
          gap: 10px;
        }
        .logo-mark {
          color: var(--accent);
          font-size: 14px;
        }
        .nav-center {
          display: flex;
          gap: 28px;
          justify-self: center;
        }
        .nav-center a {
          color: var(--text);
          text-decoration: none;
          font-size: 14px;
          font-weight: 500;
          transition: color .2s ease;
        }
        .nav-center a:hover { color: var(--accent); }
        .nav-actions { justify-self: end; }

        .btn-accent {
          background: var(--text);
          color: #FFFFFF;
          border: none;
          padding: 12px 22px;
          border-radius: 0;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          transition: background .2s ease, transform .2s ease;
          font-family: inherit;
        }
        .btn-accent:hover { background: var(--accent); }

        /* ===================== HERO ===================== */
        .hero {
          border-bottom: 1px solid var(--border);
        }
        .hero-grid {
          max-width: 1280px;
          margin: 0 auto;
          padding: 90px 32px 110px;
          display: grid;
          grid-template-columns: 1.1fr 0.9fr;
          gap: 72px;
          align-items: center;
        }
        .eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.14em;
          color: var(--muted);
          border: 1px solid var(--border);
          padding: 10px 16px;
          border-radius: 0;
          margin-bottom: 32px;
        }
        .dot-rec {
          width: 9px;
          height: 9px;
          background: var(--accent);
          border-radius: 999px;
          display: inline-block;
          box-shadow: 0 0 0 4px rgba(225,29,72,0.15);
          animation: pulse 1.6s ease-in-out infinite;
        }
        @keyframes pulse {
          0%,100% { box-shadow: 0 0 0 4px rgba(225,29,72,0.18); }
          50% { box-shadow: 0 0 0 8px rgba(225,29,72,0.05); }
        }
        .hero-title {
          font-size: clamp(44px, 6.4vw, 92px);
          line-height: 0.96;
          letter-spacing: -0.035em;
          font-weight: 700;
          margin-bottom: 28px;
        }
        .hero-subtitle {
          font-size: 18px;
          color: var(--muted);
          max-width: 520px;
          margin: 0 0 36px;
        }
        .hero-cta-row {
          display: flex;
          gap: 16px;
          align-items: center;
          margin-bottom: 48px;
          flex-wrap: wrap;
        }
        .btn-primary {
          background: var(--accent);
          color: #FFFFFF;
          border: 1px solid var(--accent);
          padding: 18px 32px;
          border-radius: 0;
          font-family: inherit;
          font-weight: 700;
          font-size: 15px;
          letter-spacing: 0.02em;
          cursor: pointer;
          transition: all .2s ease;
          text-transform: uppercase;
        }
        .btn-primary:hover {
          background: var(--text);
          border-color: var(--text);
          transform: translateY(-2px);
        }
        .btn-primary.full { width: 100%; }
        .btn-ghost {
          background: transparent;
          color: var(--text);
          border: 1px solid var(--text);
          padding: 18px 28px;
          border-radius: 0;
          font-family: inherit;
          font-weight: 600;
          font-size: 15px;
          cursor: pointer;
          text-decoration: none;
          display: inline-block;
          transition: all .2s ease;
        }
        .btn-ghost:hover {
          background: var(--text);
          color: #FFFFFF;
        }
        .btn-ghost.full {
          width: 100%;
          text-align: center;
          padding: 16px 24px;
        }

        .hero-meta {
          display: flex;
          gap: 48px;
          padding-top: 28px;
          border-top: 1px solid var(--border);
        }
        .hero-meta div { display: flex; flex-direction: column; gap: 4px; }
        .hero-meta strong {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 28px;
          font-weight: 700;
          color: var(--text);
        }
        .hero-meta span { font-size: 13px; color: var(--muted); }

        .hero-media {
          position: relative;
          aspect-ratio: 1 / 1.05;
          border: 1px solid var(--border);
          overflow: hidden;
        }
        .hero-media img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          filter: grayscale(0%) contrast(1.05);
        }
        .hero-media-label {
          position: absolute;
          bottom: 18px;
          left: 18px;
          background: #FFFFFF;
          border: 1px solid var(--text);
          padding: 8px 14px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.14em;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        /* ===================== SECTION BLOCKS ===================== */
        .section-block {
          max-width: 1280px;
          margin: 0 auto;
          padding: 120px 32px;
          border-bottom: 1px solid var(--border);
        }
        .block-header { max-width: 820px; margin-bottom: 64px; }
        .section-index {
          display: inline-block;
          font-family: 'Space Grotesk', sans-serif;
          font-size: 13px;
          color: var(--muted);
          letter-spacing: 0.2em;
          margin-bottom: 20px;
        }
        .section-title {
          font-size: clamp(36px, 4.6vw, 64px);
          line-height: 1.02;
          letter-spacing: -0.03em;
          margin-bottom: 18px;
        }
        .section-lead {
          font-size: 18px;
          color: var(--muted);
          max-width: 600px;
          margin: 0;
        }

        /* Two columns Como Funciona */
        .grid-two {
          display: grid;
          grid-template-columns: 1fr 1fr;
          border: 1px solid var(--border);
        }
        .grid-col {
          padding: 56px 48px;
          border-right: 1px solid var(--border);
        }
        .grid-col:last-child { border-right: none; }
        .grid-col-dark {
          background: var(--text);
          color: #FFFFFF;
        }
        .grid-col-dark .col-label { color: rgba(255,255,255,0.55); }
        .grid-col-dark .step-list li p { color: rgba(255,255,255,0.65); }
        .grid-col-dark .step-num { background: #FFFFFF; color: var(--text); }

        .col-head { margin-bottom: 40px; }
        .col-label {
          display: block;
          font-size: 12px;
          letter-spacing: 0.18em;
          color: var(--muted);
          margin-bottom: 16px;
          font-weight: 600;
        }
        .col-head h3 {
          font-size: 32px;
          line-height: 1.1;
          letter-spacing: -0.02em;
        }
        .step-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: 28px;
        }
        .step-list li {
          display: grid;
          grid-template-columns: 44px 1fr;
          gap: 20px;
          align-items: start;
        }
        .step-num {
          background: var(--text);
          color: #FFFFFF;
          width: 36px;
          height: 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 700;
          font-size: 14px;
        }
        .step-list li strong {
          display: block;
          font-size: 17px;
          margin-bottom: 6px;
          font-weight: 600;
        }
        .step-list li p {
          margin: 0;
          color: var(--muted);
          font-size: 15px;
        }

        /* Features grid */
        .section-features { background: var(--bg); }
        .features-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          border: 1px solid var(--border);
          border-right: none;
          border-bottom: none;
        }
        .feature-cell {
          border-right: 1px solid var(--border);
          border-bottom: 1px solid var(--border);
          padding: 40px 36px;
          transition: background .2s ease;
        }
        .feature-cell:hover { background: var(--surface); }
        .feature-label {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 12px;
          color: var(--muted);
          letter-spacing: 0.18em;
          margin-bottom: 20px;
        }
        .feature-cell h4 {
          font-size: 22px;
          margin-bottom: 10px;
          letter-spacing: -0.02em;
        }
        .feature-cell p {
          color: var(--muted);
          margin: 0;
          font-size: 15px;
        }

        /* Testimonial editorial */
        .testimonial {
          border-bottom: 1px solid var(--border);
        }
        .testimonial-inner {
          max-width: 1080px;
          margin: 0 auto;
          padding: 120px 32px;
          position: relative;
        }
        .quote-mark {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 180px;
          line-height: 0.6;
          color: var(--accent);
          position: absolute;
          top: 100px;
          left: 16px;
          opacity: 0.18;
          font-weight: 700;
        }
        .testimonial-quote {
          font-family: 'Space Grotesk', sans-serif;
          font-size: clamp(32px, 4.2vw, 56px);
          line-height: 1.1;
          letter-spacing: -0.025em;
          font-weight: 600;
          margin: 0 0 40px;
          max-width: 900px;
        }
        .testimonial-author {
          display: flex;
          align-items: center;
          gap: 16px;
        }
        .testimonial-author img {
          width: 56px;
          height: 56px;
          object-fit: cover;
          border: 1px solid var(--border);
        }
        .testimonial-author strong {
          display: block;
          font-size: 16px;
        }
        .testimonial-author span { color: var(--muted); font-size: 14px; }

        /* Pricing */
        .pricing-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          border: 1px solid var(--border);
        }
        .price-cell {
          padding: 48px 40px;
          border-right: 1px solid var(--border);
          position: relative;
        }
        .price-cell:last-child { border-right: none; }
        .price-cell-feature {
          background: var(--text);
          color: #FFFFFF;
        }
        .price-cell-feature .price-label,
        .price-cell-feature .price-list li { color: rgba(255,255,255,0.7); }
        .price-ribbon {
          position: absolute;
          top: 20px;
          right: 20px;
          background: var(--accent);
          color: #FFFFFF;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.16em;
          padding: 6px 12px;
        }
        .price-label {
          font-size: 12px;
          letter-spacing: 0.18em;
          color: var(--muted);
          margin-bottom: 16px;
          font-weight: 600;
        }
        .price-value {
          font-family: 'Space Grotesk', sans-serif;
          font-size: 64px;
          font-weight: 700;
          letter-spacing: -0.03em;
          margin-bottom: 24px;
          line-height: 1;
        }
        .price-value small {
          font-size: 16px;
          color: var(--muted);
          font-weight: 400;
          margin-left: 4px;
        }
        .price-cell-feature .price-value small { color: rgba(255,255,255,0.6); }
        .price-list {
          list-style: none;
          padding: 0;
          margin: 0 0 36px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .price-list li {
          font-size: 15px;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .price-list li::before {
          content: '';
          width: 14px;
          height: 1px;
          background: currentColor;
          display: inline-block;
          opacity: 0.5;
        }

        /* FOOTER */
        .footer-massive {
          background: #09090B;
          color: #FFFFFF;
          padding: 100px 32px 40px;
        }
        .footer-top {
          max-width: 1280px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 72px;
          padding-bottom: 80px;
          border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .footer-links-row {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 32px;
        }
        .footer-links-row h4 {
          font-size: 13px;
          letter-spacing: 0.18em;
          color: rgba(255,255,255,0.5);
          margin-bottom: 20px;
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
        }
        .footer-links-row a {
          display: block;
          color: #FFFFFF;
          text-decoration: none;
          font-size: 14px;
          margin-bottom: 10px;
          transition: color .2s;
        }
        .footer-links-row a:hover { color: var(--accent); }
        .footer-cta h2 {
          font-size: clamp(36px, 4.6vw, 64px);
          margin-bottom: 24px;
          letter-spacing: -0.03em;
        }
        .footer-btn { background: var(--accent); border-color: var(--accent); }
        .footer-btn:hover { background: #FFFFFF; color: var(--text); border-color: #FFFFFF; }

        .footer-wordmark {
          font-family: 'Space Grotesk', sans-serif;
          font-size: clamp(80px, 20vw, 280px);
          font-weight: 700;
          letter-spacing: -0.06em;
          line-height: 0.85;
          text-align: center;
          margin: 60px 0 40px;
          background: linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(255,255,255,0.15) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .footer-bottom {
          max-width: 1280px;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          font-size: 13px;
          color: rgba(255,255,255,0.5);
          padding-top: 24px;
          border-top: 1px solid rgba(255,255,255,0.08);
          flex-wrap: wrap;
          gap: 12px;
        }

        /* Modal */
        .modal-backdrop {
          position: fixed; inset: 0; background: rgba(9,9,11,0.6);
          display: flex; align-items: center; justify-content: center;
          z-index: 9999; padding: 24px;
        }
        .modal-card {
          background: #FFFFFF; color: var(--text); padding: 40px;
          max-width: 440px; width: 100%; border: 1px solid var(--border);
        }
        .modal-card h3 { margin-bottom: 12px; font-size: 24px; }
        .modal-card p { color: var(--muted); margin-bottom: 24px; }

        /* Responsive */
        @media (max-width: 960px) {
          .nav-container { grid-template-columns: 1fr auto; }
          .nav-center { display: none; }
          .hero-grid { grid-template-columns: 1fr; padding: 60px 24px 72px; gap: 48px; }
          .hero-meta { gap: 28px; }
          .grid-two, .pricing-grid { grid-template-columns: 1fr; }
          .grid-col, .price-cell { border-right: none; border-bottom: 1px solid var(--border); }
          .grid-col-dark { border-bottom: none; }
          .features-grid { grid-template-columns: 1fr 1fr; }
          .footer-top { grid-template-columns: 1fr; gap: 48px; }
          .section-block { padding: 72px 24px; }
          .testimonial-inner { padding: 72px 24px; }
        }
        @media (max-width: 560px) {
          .features-grid { grid-template-columns: 1fr; }
          .hero-meta { flex-wrap: wrap; }
          .footer-links-row { grid-template-columns: 1fr 1fr; }
        }
      `}</style>
    </div>
  )
}
