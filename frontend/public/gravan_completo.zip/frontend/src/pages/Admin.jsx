import React, { useEffect, useState } from 'react'
import { api } from '../lib/api'

function fmt(cents) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format((cents ?? 0) / 100)
}

const ABAS = [
  { id: 'analiticos',  label: 'Analíticos',          icon: '▦' },
  { id: 'receita',     label: 'Receita',             icon: '◎' },
  { id: 'generos',     label: 'Gêneros mais procurados', icon: '♫' },
  { id: 'saques',      label: 'Autorizar saques',   icon: '💸' },
  { id: 'auditoria',   label: 'Auditoria de splits', icon: '⊟' },
]

function StatCard({ label, value, sublabel, color = 'var(--brand)', big = false }) {
  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 14, padding: '16px 18px',
    }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 1 }}>
        {label}
      </div>
      <div style={{ fontSize: big ? 28 : 22, fontWeight: 800, color, marginTop: 6 }}>
        {value}
      </div>
      {sublabel && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{sublabel}</div>}
    </div>
  )
}

export default function Admin() {
  const [aba, setAba] = useState('analiticos')
  const [resumo,  setResumo]  = useState(null)
  const [saques,  setSaques]  = useState([])
  const [saqueLoading, setSaqueLoading] = useState(false)
  const [generos, setGeneros] = useState([])
  const [audit,   setAudit]   = useState([])
  const [volume,  setVolume]  = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      api.get('/admin/bi/resumo').catch(() => null),
      api.get('/admin/bi/generos').catch(() => []),
      api.get('/admin/bi/auditoria?per_page=30').catch(() => []),
      api.get('/admin/bi/volume?dias=30').catch(() => []),
    ]).then(([r, g, a, v]) => {
      setResumo(r); setGeneros(g); setAudit(a); setVolume(v)
    }).finally(() => setLoading(false))
  }, [])

  async function loadSaques() {
    setSaqueLoading(true)
    try {
      const data = await api.get('/admin/saques')
      setSaques(data)
    } catch (e) { console.error(e) }
    finally { setSaqueLoading(false) }
  }

  useEffect(() => {
    if (aba !== 'saques') return
    loadSaques()
    const intv = setInterval(() => loadSaques(), 5000) // auto-refresh 5s
    return () => clearInterval(intv)
  }, [aba])

  async function handleSaque(id, acao, motivo) {
    if (acao === 'rejeitado' && !motivo) {
      const m = prompt('Motivo da rejeição (obrigatório):')
      if (!m) return
      motivo = m
    }
    if (!confirm(`Confirmar ${acao === 'pago' ? 'marcar como PAGO' : acao === 'processando' ? 'marcar como PROCESSANDO' : 'REJEITAR e devolver valor'}?`)) return
    try {
      await api.post(`/admin/saques/${id}/aprovar`, { acao, motivo })
      await loadSaques()
    } catch (e) {
      alert('Erro: ' + e.message)
    }
  }

  if (loading) return <div style={{ padding: 32 }}><p style={{ color: 'var(--text-muted)' }}>Carregando painel…</p></div>

  return (
    <div style={{ padding: 32, maxWidth: 1100 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800 }}>Painel administrador</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Visão consolidada da plataforma Pitch.me</p>
      </div>

      {/* Abas */}
      <div style={{
        display: 'flex', gap: 4, marginBottom: 24,
        borderBottom: '1px solid var(--border)',
      }}>
        {ABAS.map(a => (
          <button key={a.id} onClick={() => setAba(a.id)}
            style={{
              padding: '10px 18px', border: 'none', background: 'none',
              cursor: 'pointer', fontSize: 14,
              fontWeight: aba === a.id ? 700 : 500,
              color: aba === a.id ? 'var(--brand)' : 'var(--text-secondary)',
              borderBottom: aba === a.id ? '3px solid var(--brand)' : '3px solid transparent',
              marginBottom: -1, display: 'flex', alignItems: 'center', gap: 6,
            }}>
            <span>{a.icon}</span> {a.label}
          </button>
        ))}
      </div>

      {/* ── ANALÍTICOS ── */}
      {aba === 'analiticos' && resumo && (
        <div>
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: 14, marginBottom: 24,
          }}>
            <StatCard label="Composições cadastradas" value={resumo.total_obras} sublabel={`${resumo.obras_publicadas} publicadas`} big color="var(--brand)" />
            <StatCard label="Vendas confirmadas"      value={resumo.total_vendas} big color="var(--success)" />
            <StatCard label="Compositores"            value={resumo.total_compositores} sublabel={`de ${resumo.total_usuarios} usuários`} />
            <StatCard label="Intérpretes"             value={resumo.total_interpretes} />
            <StatCard label="Ofertas pendentes"       value={resumo.ofertas_pendentes} color="var(--warning)" />
          </div>

          <div className="card" style={{ background: 'linear-gradient(135deg, #BE123C, #09090B)', border: 'none', color: '#fff', marginBottom: 16, boxShadow: '0 8px 32px rgba(225,29,72,.25)' }}>
            <h2 style={{ fontSize: 14, fontWeight: 600, color: 'rgba(255,255,255,.7)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>
              Receita total da plataforma
            </h2>
            <div style={{ fontSize: 42, fontWeight: 800, color: '#fff', marginBottom: 6 }}>
              {fmt(resumo.receita_bruta_cents)}
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 16 }}>
              <div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,.5)' }}>RETIDO PELA PLATAFORMA</div>
                <div style={{ fontSize: 22, fontWeight: 700, color: '#34D399', marginTop: 4 }}>
                  {fmt(resumo.receita_plataforma_cents)}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,.5)' }}>PAGO AOS COMPOSITORES</div>
                <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginTop: 4 }}>
                  {fmt(resumo.receita_compositores_cents)}
                </div>
              </div>
            </div>
          </div>


        </div>
      )}

      {/* ── RECEITA ── */}
      {aba === 'receita' && resumo && (
        <div>
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: 14, marginBottom: 24,
          }}>
            <StatCard label="Receita bruta total"     value={fmt(resumo.receita_bruta_cents)} sublabel="Soma de todas as vendas confirmadas" big color="var(--brand)" />
            <StatCard label="Receita líquida da plataforma" value={fmt(resumo.receita_plataforma_cents)} sublabel="Retido direto na fonte" big color="var(--success)" />
            <StatCard label="Pago aos compositores"   value={fmt(resumo.receita_compositores_cents)} sublabel="Distribuído via wallets dos compositores" big color="var(--brand)" />
          </div>

          <div className="card">
            <h2 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>Histórico de vendas (últimas)</h2>
            {volume.length === 0 ? (
              <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Nenhuma venda registrada ainda.</p>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border)' }}>
                      {['Data', 'Método', 'Status', 'Vendas', 'Bruta', 'Plataforma', 'Compositores'].map(h => (
                        <th key={h} style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {volume.map((v, i) => (
                      <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{new Date(v.dia).toLocaleDateString('pt-BR')}</td>
                        <td style={{ padding: '10px 12px', textTransform: 'uppercase', fontWeight: 600 }}>{v.metodo}</td>
                        <td style={{ padding: '10px 12px' }}>{v.status}</td>
                        <td style={{ padding: '10px 12px' }}>{v.total_transacoes}</td>
                        <td style={{ padding: '10px 12px' }}>{fmt(v.receita_bruta_cents)}</td>
                        <td style={{ padding: '10px 12px', color: 'var(--success)' }}>{fmt(v.receita_plataforma_cents)}</td>
                        <td style={{ padding: '10px 12px', color: 'var(--brand)' }}>{fmt(v.pago_compositores_cents)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── GÊNEROS ── */}
      {aba === 'generos' && (
        <div className="card">
          <h2 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>Gêneros mais procurados</h2>
          {generos.length === 0 ? (
            <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Sem dados ainda.</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  {['Gênero', 'Obras publicadas', 'Vendas', 'Receita gerada'].map(h => (
                    <th key={h} style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {generos.map((g, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '12px', fontWeight: 700 }}>{g.genero}</td>
                    <td style={{ padding: '12px' }}>{g.total_obras}</td>
                    <td style={{ padding: '12px', color: 'var(--success)' }}>{g.total_vendas}</td>
                    <td style={{ padding: '12px', color: 'var(--brand)', fontWeight: 700 }}>{fmt(g.receita_cents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}


      {/* ── AUTORIZAR SAQUES ── */}
      {aba === 'saques' && (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
            <div>
              <h2 style={{ fontSize: 15, fontWeight: 700 }}>Saques solicitados</h2>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                <span style={{
                  display: 'inline-block', width: 8, height: 8, borderRadius: '50%',
                  background: 'var(--success)', marginRight: 6,
                  animation: 'pulse 2s infinite',
                }}></span>
                Atualização automática a cada 5 segundos
                {saques.filter(s => s.status === 'solicitado').length > 0 && (
                  <span style={{
                    marginLeft: 10, padding: '2px 8px',
                    background: 'var(--warning-bg)', color: 'var(--warning)',
                    borderRadius: 99, fontSize: 11, fontWeight: 700,
                  }}>
                    {saques.filter(s => s.status === 'solicitado').length} aguardando
                  </span>
                )}
              </p>
            </div>
            <button onClick={loadSaques} style={{ background: 'none', border: '1px solid var(--border)', padding: '6px 12px', borderRadius: 8, color: 'var(--brand)', fontSize: 13, cursor: 'pointer' }}>
              ↻ atualizar agora
            </button>
          </div>
          <style>{`
            @keyframes pulse {
              0%, 100% { opacity: 1; }
              50% { opacity: 0.4; }
            }
          `}</style>

          {saqueLoading ? (
            <p style={{ color: 'var(--text-muted)' }}>Carregando…</p>
          ) : saques.length === 0 ? (
            <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Nenhum saque solicitado no momento.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {saques.map(s => {
                const statusMap = {
                  solicitado:  { bg: 'var(--warning-bg)', cor: 'var(--warning)', label: '⏱ Solicitado' },
                  processando: { bg: 'var(--brand-light)', cor: 'var(--brand)',  label: '↻ Processando' },
                  pago:        { bg: 'var(--success-bg)', cor: 'var(--success)', label: '✓ Pago' },
                  rejeitado:   { bg: 'var(--error-bg)',   cor: 'var(--error)',   label: '✕ Rejeitado' },
                }
                const st = statusMap[s.status] || statusMap.solicitado
                return (
                  <div key={s.id} style={{
                    padding: 16, background: 'var(--surface-2)', borderRadius: 10,
                    border: '1px solid var(--border)',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 18 }}>{fmt(s.valor_cents)}</div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                          {s.perfis?.nome_artistico || s.perfis?.nome} · {s.perfis?.email}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                          Solicitado em {new Date(s.created_at).toLocaleString('pt-BR')}
                          {s.processed_at && ' · processado em ' + new Date(s.processed_at).toLocaleString('pt-BR')}
                        </div>
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 600, padding: '4px 12px', borderRadius: 99, background: st.bg, color: st.cor }}>
                        {st.label}
                      </span>
                    </div>

                    <div style={{ padding: 10, background: 'var(--surface)', borderRadius: 8, marginBottom: 10, fontSize: 13 }}>
                      <strong>PayPal:</strong> <code>{s.paypal_email}</code>
                    </div>

                    {s.motivo_rejeicao && (
                      <div style={{ padding: 10, background: 'var(--error-bg)', borderRadius: 8, marginBottom: 10, fontSize: 12, color: 'var(--error)' }}>
                        <strong>Motivo da rejeição:</strong> {s.motivo_rejeicao}
                      </div>
                    )}

                    {s.status === 'solicitado' && (
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        <button className="btn btn-secondary btn-sm" onClick={() => handleSaque(s.id, 'processando')}>
                          ↻ Em processamento
                        </button>
                        <button className="btn btn-primary btn-sm" onClick={() => handleSaque(s.id, 'pago')}>
                          ✓ Marcar como pago
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleSaque(s.id, 'rejeitado')}>
                          ✕ Rejeitar
                        </button>
                      </div>
                    )}

                    {s.status === 'processando' && (
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                        <button className="btn btn-primary btn-sm" onClick={() => handleSaque(s.id, 'pago')}>
                          ✓ Confirmar pagamento
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleSaque(s.id, 'rejeitado')}>
                          ✕ Rejeitar
                        </button>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* ── AUDITORIA ── */}
      {aba === 'auditoria' && (
        <div className="card">
          <h2 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>Auditoria de splits financeiros</h2>
          {audit.length === 0 ? (
            <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Nenhum split registrado ainda.</p>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    {['Data', 'Obra', 'Compositor', 'Venda', 'Recebido', 'Status'].map(h => (
                      <th key={h} style={{ padding: '10px', textAlign: 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {audit.map((a, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td style={{ padding: '10px', whiteSpace: 'nowrap' }}>{new Date(a.created_at).toLocaleDateString('pt-BR')}</td>
                      <td style={{ padding: '10px', fontWeight: 600 }}>{a.obra_nome}</td>
                      <td style={{ padding: '10px' }}>{a.compositor_nome}</td>
                      <td style={{ padding: '10px' }}>{fmt(a.valor_cents)}</td>
                      <td style={{ padding: '10px', color: 'var(--success)', fontWeight: 700 }}>{fmt(a.pago_cents)}</td>
                      <td style={{ padding: '10px' }}>
                        <span style={{
                          fontSize: 11, fontWeight: 600,
                          padding: '2px 8px', borderRadius: 99,
                          background: a.status === 'confirmada' ? 'var(--success-bg)' : 'var(--surface-2)',
                          color: a.status === 'confirmada' ? 'var(--success)' : 'var(--text-muted)',
                        }}>{a.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
