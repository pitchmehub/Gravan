import React, { useState, useEffect } from 'react'
import { api } from '../lib/api'

function fmt(cents) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format((cents ?? 0) / 100)
}

const STATUS_BADGE = {
  solicitado:  { bg: 'var(--warning-bg)', cor: 'var(--warning)', label: '⏱ Solicitado' },
  processando: { bg: 'var(--brand-light)', cor: 'var(--brand)',  label: '↻ Processando' },
  pago:        { bg: 'var(--success-bg)', cor: 'var(--success)', label: '✓ Pago' },
  rejeitado:   { bg: 'var(--error-bg)',   cor: 'var(--error)',   label: '✕ Rejeitado' },
}

export default function Saques() {
  const [wallet,  setWallet]  = useState(null)
  const [loading, setLoading] = useState(true)
  const [valor,   setValor]   = useState('')
  const [email,   setEmail]   = useState('')
  const [enviando, setEnviando] = useState(false)
  const [erro,    setErro]    = useState('')
  const [sucesso, setSucesso] = useState(false)

  async function load() {
    setLoading(true)
    try {
      const data = await api.get('/perfis/me/wallet')
      setWallet(data)
    } catch (e) {
      setErro(e.message)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  async function solicitar(e) {
    e.preventDefault()
    setErro(''); setSucesso(false); setEnviando(true)
    try {
      const valorNum = parseFloat((valor || '').replace(',', '.'))
      if (isNaN(valorNum) || valorNum < 10) {
        throw new Error('Valor mínimo: R$ 10,00')
      }
      await api.post('/perfis/me/saques', {
        paypal_email: email.trim().toLowerCase(),
        valor_cents:  Math.round(valorNum * 100),
      })
      setSucesso(true)
      setValor('')
      load()
    } catch (e) {
      setErro(e.message ?? 'Erro ao solicitar saque.')
    } finally { setEnviando(false) }
  }

  if (loading) return <div style={{ padding: 32 }}><p style={{ color: 'var(--text-muted)' }}>Carregando…</p></div>

  const saldo = wallet?.saldo_cents ?? 0
  const totalSaques = (wallet?.saques ?? []).reduce((s, x) => s + (x.status === 'pago' ? x.valor_cents : 0), 0)
  const pendente = (wallet?.saques ?? []).reduce((s, x) => s + (['solicitado','processando'].includes(x.status) ? x.valor_cents : 0), 0)

  return (
    <div style={{ padding: 32, maxWidth: 880 }}>
      <h1 style={{ fontSize: 24, fontWeight: 800 }}>Saques via PayPal</h1>
      <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>
        Receba seus ganhos diretamente na sua conta PayPal.
      </p>

      {/* Saldo */}
      <div style={{
        padding: 24, marginBottom: 24,
        background: 'linear-gradient(135deg,#BE123C,#09090B)',
        borderRadius: 16, color: '#fff',
      }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,.7)', letterSpacing: 1, textTransform: 'uppercase' }}>
          Saldo disponível
        </div>
        <div style={{ fontSize: 38, fontWeight: 800, marginTop: 6 }}>{fmt(saldo)}</div>
        <div style={{ display: 'flex', gap: 24, marginTop: 16, fontSize: 12 }}>
          <div>
            <div style={{ color: 'rgba(255,255,255,.6)' }}>JÁ SACADO</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginTop: 2 }}>{fmt(totalSaques)}</div>
          </div>
          <div>
            <div style={{ color: 'rgba(255,255,255,.6)' }}>EM PROCESSAMENTO</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginTop: 2 }}>{fmt(pendente)}</div>
          </div>
        </div>
      </div>

      {/* Formulário */}
      <div className="card" style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Solicitar saque</h2>

        {saldo < 1000 ? (
          <div style={{ padding: 16, background: 'var(--surface-2)', borderRadius: 8 }}>
            <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
              💡 Você precisa de pelo menos <strong>R$ 10,00</strong> de saldo para solicitar um saque.
            </p>
          </div>
        ) : (
          <form onSubmit={solicitar}>
            <div className="form-group">
              <label className="form-label">Email da sua conta PayPal *</label>
              <input
                className="input" type="email" required
                placeholder="seu-email@paypal.com"
                value={email} onChange={e => setEmail(e.target.value)}
              />
              <small style={{ color: 'var(--text-muted)', fontSize: 12 }}>
                Certifique-se de que o email está cadastrado na sua conta PayPal.
              </small>
            </div>

            <div className="form-group">
              <label className="form-label">Valor em reais (R$) *</label>
              <input
                className="input" type="text" required
                placeholder="Ex: 50,00"
                value={valor} onChange={e => setValor(e.target.value)}
              />
              <small style={{ color: 'var(--text-muted)', fontSize: 12 }}>
                Mínimo: R$ 10,00 · Disponível: <strong>{fmt(saldo)}</strong>
              </small>
            </div>

            {erro    && <div style={{ padding: 12, background: 'var(--error-bg)',   color: 'var(--error)',   borderRadius: 8, fontSize: 13, marginBottom: 12 }}>{erro}</div>}
            {sucesso && <div style={{ padding: 12, background: 'var(--success-bg)', color: 'var(--success)', borderRadius: 8, fontSize: 13, marginBottom: 12 }}>✓ Saque solicitado! Você receberá o valor em até 3 dias úteis.</div>}

            <button type="submit" className="btn btn-primary" disabled={enviando}>
              {enviando ? 'Processando…' : '💸 Solicitar saque'}
            </button>
          </form>
        )}
      </div>

      {/* Histórico */}
      <div className="card">
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 14 }}>Histórico de saques</h2>
        {(wallet?.saques ?? []).length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Nenhum saque solicitado ainda.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {wallet.saques.map(s => {
              const badge = STATUS_BADGE[s.status] ?? STATUS_BADGE.solicitado
              return (
                <div key={s.id} style={{
                  padding: 14, background: 'var(--surface-2)',
                  borderRadius: 10,
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 16 }}>{fmt(s.valor_cents)}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                      {s.paypal_email} · {new Date(s.created_at).toLocaleString('pt-BR')}
                    </div>
                  </div>
                  <span style={{
                    fontSize: 12, fontWeight: 600,
                    padding: '4px 12px', borderRadius: 99,
                    background: badge.bg, color: badge.cor,
                  }}>{badge.label}</span>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
