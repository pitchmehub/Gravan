import React, { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { PlayerProvider } from './contexts/PlayerContext'
import SideMenu      from './components/SideMenu'
import GlobalPlayer  from './components/GlobalPlayer'
import PWAInstaller  from './components/PWAInstaller'
import PWAInstall    from './components/PWAInstall'
import Landing       from './pages/Landing'
import Login         from './pages/Login'
import Dashboard     from './pages/Dashboard'
import Descoberta    from './pages/Descoberta'
import NovaObra      from './pages/NovaObra'
import MinhasObras   from './pages/MinhasObras'
import Comprar       from './pages/Comprar'
import Compras       from './pages/Compras'
import Saques        from './pages/Saques'
import Ofertas       from './pages/Ofertas'
import Admin         from './pages/Admin'
import EditarPerfil  from './pages/EditarPerfil'
import CompletarCadastro from './pages/CompletarCadastro'
import PagamentoSucesso   from './pages/PagamentoSucesso'
import PagamentoCancelado from './pages/PagamentoCancelado'
import './styles/global.css'
import './components/GlobalPlayer.css'

function PrivateRoute({ children, roles }) {
  const { user, perfil, loading } = useAuth()
  if (loading) return <div style={{ padding: 40, color: '#71717A', fontFamily: 'IBM Plex Sans, system-ui, sans-serif' }}>Carregando…</div>
  if (!user)   return <Navigate to="/login" replace />
  if (roles && perfil && !roles.includes(perfil.role)) return <Navigate to="/descoberta" replace />
  return children
}

function AppShell({ children }) {
  const [collapsed, setCollapsed] = useState(false)
  const sideW = collapsed ? 64 : 240
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#FFFFFF' }}>
      <SideMenu onCollapse={setCollapsed} />
      <main style={{
        marginLeft: sideW, flex: 1,
        transition: 'margin-left .2s ease',
        minWidth: 0, background: '#FFFFFF',
      }}>
        {children}
      </main>
      <GlobalPlayer />
      <PWAInstall />
    </div>
  )
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/"              element={<Landing />} />
      <Route path="/login"         element={<Login />} />

      <Route path="/descoberta"    element={<PrivateRoute><AppShell><Descoberta /></AppShell></PrivateRoute>} />
      <Route path="/dashboard"     element={<PrivateRoute><AppShell><Dashboard /></AppShell></PrivateRoute>} />
      <Route path="/obras"         element={<PrivateRoute roles={['compositor','administrador']}><AppShell><MinhasObras /></AppShell></PrivateRoute>} />
      <Route path="/obras/nova"    element={<PrivateRoute roles={['compositor','administrador']}><AppShell><NovaObra /></AppShell></PrivateRoute>} />
      <Route path="/saques"        element={<PrivateRoute roles={['compositor','administrador']}><AppShell><Saques /></AppShell></PrivateRoute>} />
      <Route path="/compras"       element={<PrivateRoute><AppShell><Compras /></AppShell></PrivateRoute>} />
      <Route path="/comprar/:obraId"      element={<PrivateRoute><AppShell><Comprar /></AppShell></PrivateRoute>} />
      <Route path="/pagamento/sucesso"    element={<PrivateRoute><AppShell><PagamentoSucesso /></AppShell></PrivateRoute>} />
      <Route path="/pagamento/cancelado"  element={<PrivateRoute><AppShell><PagamentoCancelado /></AppShell></PrivateRoute>} />
      <Route path="/ofertas"       element={<PrivateRoute><AppShell><Ofertas /></AppShell></PrivateRoute>} />
      <Route path="/perfil/editar" element={<PrivateRoute><AppShell><EditarPerfil /></AppShell></PrivateRoute>} />
      <Route path="/perfil/completar" element={<PrivateRoute><AppShell><CompletarCadastro /></AppShell></PrivateRoute>} />
      <Route path="/admin"         element={<PrivateRoute roles={['administrador']}><AppShell><Admin /></AppShell></PrivateRoute>} />

      <Route path="*"              element={<Navigate to="/descoberta" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <PlayerProvider>
          <AppRoutes />
          <PWAInstaller />
        </PlayerProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}
