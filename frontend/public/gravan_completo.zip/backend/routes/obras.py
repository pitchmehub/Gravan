"""Routes: /api/obras

CORREÇÕES DE VULNERABILIDADES:
- #12 (MÉDIA): IP hashing para LGPD compliance
- #14 (MÉDIA): Audit logging
"""
import json
from datetime import datetime
from flask import Blueprint, request, jsonify, g, abort
from middleware.auth import require_auth
from services.obras import ObraService
from db.supabase_client import get_supabase
from utils.crypto import hash_ip, decrypt_pii

obras_bp = Blueprint("obras", __name__)


def _get_perfil():
    """Carrega perfil completo com cadastro_completo."""
    sb = get_supabase()
    r = sb.table("perfis").select("*").eq("id", g.user.id).single().execute()
    return r.data if r.data else None


@obras_bp.route("", methods=["POST"])
@obras_bp.route("/", methods=["POST"])
@require_auth
def criar_obra():
    perfil = _get_perfil()
    if not perfil:
        abort(404, description="Perfil não encontrado.")
    if perfil.get("role") not in ("compositor", "administrador"):
        abort(403, description="Apenas compositores podem cadastrar obras.")
    if not perfil.get("cadastro_completo"):
        abort(422, description="Você precisa completar seu cadastro (CPF, RG e endereço) antes de publicar uma obra.")

    if "audio" not in request.files:
        abort(422, description="Campo 'audio' é obrigatório.")
    audio_file = request.files["audio"]
    if not audio_file.filename.lower().endswith(".mp3"):
        abort(422, description="Apenas arquivos .mp3 são aceitos.")

    audio_bytes = audio_file.read()

    nome  = request.form.get("nome", "").strip()
    letra = request.form.get("letra", "").strip()
    if not nome or not letra:
        abort(422, description="Campos 'nome' e 'letra' são obrigatórios.")

    genero = request.form.get("genero")

    try:
        preco_cents = int(request.form.get("preco_cents", 0))
        if preco_cents < 100: raise ValueError()
    except (ValueError, TypeError):
        abort(422, description="'preco_cents' deve ser inteiro >= 100.")

    try:
        coautorias = json.loads(request.form.get("coautorias", "[]"))
        if not isinstance(coautorias, list): raise ValueError()
    except (ValueError, json.JSONDecodeError):
        abort(422, description="'coautorias' deve ser array JSON válido.")

    termos_aceitos = request.form.get("termos_aceitos", "false").lower() == "true"
    if not termos_aceitos:
        abort(422, description="Você precisa aceitar os Termos de Uso.")

    obra_editada = request.form.get("obra_editada", "false").lower() == "true"
    if obra_editada:
        abort(422, description="Obras já editadas por outras editoras não podem ser cadastradas. Para publicar, a obra precisa estar livre de contratos de edição prévios.")

    contrato_aceito = request.form.get("contrato_aceito", "false").lower() == "true"
    if not contrato_aceito:
        abort(422, description="Você precisa assinar o Contrato de Edição para prosseguir.")

    service = ObraService()
    obra = service.criar_obra(
        titular_id=g.user.id,
        nome=nome, letra=letra, genero=genero,
        preco_cents=preco_cents,
        audio_bytes=audio_bytes,
        coautorias=coautorias,
        termos_aceitos=termos_aceitos,
    )

    # Gera e assina o contrato de edição
    sb = get_supabase()
    tpl = sb.table("landing_content").select("valor").eq("id", "contrato_edicao_template").single().execute()
    tpl_texto = (tpl.data or {}).get("valor", "")

    endereco = ", ".join(filter(None, [
        perfil.get("endereco_rua"),
        perfil.get("endereco_numero"),
        perfil.get("endereco_compl"),
        perfil.get("endereco_bairro"),
        perfil.get("endereco_cidade"),
        perfil.get("endereco_uf"),
        f"CEP {perfil['endereco_cep']}" if perfil.get("endereco_cep") else None,
    ]))
    agora_str = datetime.utcnow().strftime("%d/%m/%Y às %H:%M UTC")
    
    # CORREÇÃO #9 (ALTA): Decripta CPF/RG para usar no contrato
    cpf_decrypted = decrypt_pii(perfil.get("cpf", ""))
    rg_decrypted = decrypt_pii(perfil.get("rg", ""))
    
    conteudo = (tpl_texto
        .replace("{{nome_completo}}", perfil.get("nome_completo") or perfil.get("nome") or "")
        .replace("{{cpf}}",            cpf_decrypted or "")
        .replace("{{rg}}",             rg_decrypted or "")
        .replace("{{endereco_completo}}", endereco or "Não informado")
        .replace("{{email}}",          perfil.get("email") or "")
        .replace("{{data_assinatura}}", agora_str)
    )

    # CORREÇÃO #12 (MÉDIA): Hash do IP para LGPD compliance
    ip_hashed = hash_ip(request.remote_addr)
    
    contrato = sb.table("contratos_edicao").insert({
        "obra_id":       obra["id"],
        "titular_id":    g.user.id,
        "conteudo":      conteudo,
        "ip_assinatura": ip_hashed,  # IP anonimizado
        "dados_titular": {
            "nome_completo":  perfil.get("nome_completo"),
            "cpf":            cpf_decrypted,  # Usa decriptado para documento legal
            "rg":             rg_decrypted,
            "endereco":       endereco,
            "email":          perfil.get("email"),
        },
    }).execute()

    if contrato.data:
        sb.table("obras").update({
            "contrato_edicao_id": contrato.data[0]["id"],
        }).eq("id", obra["id"]).execute()

    return jsonify(obra), 201


@obras_bp.route("/<obra_id>", methods=["DELETE"])
@require_auth
def excluir_obra(obra_id):
    sb = get_supabase()
    obra = sb.table("obras").select("id, titular_id, audio_path").eq("id", obra_id).single().execute()
    if not obra.data:
        abort(404, description="Obra não encontrada.")
    perfil = _get_perfil()
    if obra.data["titular_id"] != g.user.id and perfil.get("role") != "administrador":
        abort(403, description="Apenas o titular pode excluir esta obra.")

    if obra.data.get("audio_path"):
        try: sb.storage.from_("obras-audio").remove([obra.data["audio_path"]])
        except Exception: pass

    sb.table("obras").delete().eq("id", obra_id).execute()
    return jsonify({"ok": True}), 200


@obras_bp.route("/minhas", methods=["GET"])
@require_auth
def minhas_obras():
    service = ObraService()
    obras = service.obras_do_compositor(perfil_id=g.user.id)
    return jsonify(obras), 200


@obras_bp.route("/catalogo", methods=["GET"])
def catalogo_publico():
    genero   = request.args.get("genero")
    page     = max(1, int(request.args.get("page", 1)))
    per_page = min(50, int(request.args.get("per_page", 20)))
    service  = ObraService()
    return jsonify(service.catalogo_publico(genero=genero, page=page, per_page=per_page)), 200


@obras_bp.route("/<obra_id>/preview-url", methods=["GET"])
@require_auth
def preview_url(obra_id):
    sb = get_supabase()
    obra = sb.table("obras").select("audio_path").eq("id", obra_id).single().execute()
    if not obra.data or not obra.data.get("audio_path"):
        abort(404, description="Áudio não encontrado.")
    signed = sb.storage.from_("obras-audio").create_signed_url(obra.data["audio_path"], 3600)
    return jsonify({"url": signed.get("signedURL") or signed.get("signedUrl")}), 200
