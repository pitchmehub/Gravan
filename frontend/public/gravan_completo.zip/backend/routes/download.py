"""
Route para download do projeto completo.
"""
from flask import Blueprint, send_file, jsonify
import os

download_bp = Blueprint("download", __name__)

@download_bp.route("/download-projeto", methods=["GET"])
def download_projeto():
    """Baixa o projeto completo em ZIP."""
    try:
        file_path = "/app/pitch_me_projeto_completo.zip"
        
        if not os.path.exists(file_path):
            return jsonify({"error": "Arquivo não encontrado"}), 404
        
        return send_file(
            file_path,
            mimetype="application/zip",
            as_attachment=True,
            download_name="pitch_me_completo.zip"
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@download_bp.route("/download-info", methods=["GET"])
def download_info():
    """Informações sobre o arquivo de download."""
    file_path = "/app/pitch_me_projeto_completo.zip"
    
    if os.path.exists(file_path):
        size = os.path.getsize(file_path)
        return jsonify({
            "disponivel": True,
            "tamanho_bytes": size,
            "tamanho_kb": round(size / 1024, 2),
            "nome": "pitch_me_completo.zip"
        }), 200
    else:
        return jsonify({"disponivel": False}), 404
