"""Routes: /api/admin — só administradores"""
from flask import Blueprint, jsonify, request, g, abort
from middleware.auth import require_auth
from db.supabase_client import get_supabase

admin_bp = Blueprint("admin", __name__)


def _check_admin():
    sb = get_supabase()
    r = sb.table("perfis").select("role").eq("id", g.user.id).single().execute()
    if not r.data or r.data.get("role") != "administrador":
        abort(403, description="Acesso restrito a administradores.")


@admin_bp.route("/bi/resumo", methods=["GET"])
@require_auth
def resumo_geral():
    _check_admin()
    sb = get_supabase()

    obras_total = sb.table("obras").select("id", count="exact").execute()
    obras_pub   = sb.table("obras").select("id", count="exact").eq("status", "publicada").execute()
    perfis      = sb.table("perfis").select("id, role", count="exact").execute()

    perfis_data = perfis.data or []
    n_compositores = sum(1 for p in perfis_data if p.get("role") == "compositor")
    n_interpretes  = sum(1 for p in perfis_data if p.get("role") == "interprete")

    trans = sb.table("transacoes").select("valor_cents, plataforma_cents, liquido_cents").eq("status", "confirmada").execute()
    trans_data = trans.data or []

    receita_bruta      = sum(t.get("valor_cents") or 0 for t in trans_data)
    receita_plataforma = sum(t.get("plataforma_cents") or 0 for t in trans_data)
    receita_compositores = sum(t.get("liquido_cents") or 0 for t in trans_data)

    ofertas_pendentes = sb.table("ofertas").select("id", count="exact").eq("status", "pendente").execute()

    return jsonify({
        "total_obras":             obras_total.count or 0,
        "obras_publicadas":        obras_pub.count or 0,
        "total_usuarios":          perfis.count or 0,
        "total_compositores":      n_compositores,
        "total_interpretes":       n_interpretes,
        "total_vendas":            len(trans_data),
        "receita_bruta_cents":     receita_bruta,
        "receita_plataforma_cents": receita_plataforma,
        "receita_compositores_cents": receita_compositores,
        "ofertas_pendentes":       ofertas_pendentes.count or 0,
    }), 200


@admin_bp.route("/bi/generos", methods=["GET"])
@require_auth
def generos_populares():
    _check_admin()
    sb = get_supabase()
    return jsonify(sb.table("bi_generos_populares").select("*").execute().data or []), 200


@admin_bp.route("/bi/volume", methods=["GET"])
@require_auth
def volume_transacional():
    _check_admin()
    sb = get_supabase()
    dias = min(int(request.args.get("dias", 30)), 365)
    return jsonify(sb.table("bi_volume_transacional").select("*").limit(dias * 4).execute().data or []), 200


@admin_bp.route("/bi/auditoria", methods=["GET"])
@require_auth
def auditoria_splits():
    _check_admin()
    sb = get_supabase()
    page     = max(1, int(request.args.get("page", 1)))
    per_page = min(100, int(request.args.get("per_page", 50)))
    offset   = (page - 1) * per_page
    return jsonify(sb.table("bi_auditoria_splits").select("*").range(offset, offset + per_page - 1).execute().data or []), 200

@admin_bp.route("/saques", methods=["GET"])
@require_auth
def listar_saques():
    _check_admin()
    sb = get_supabase()
    status = request.args.get("status")
    query = (
        sb.table("saques")
        .select("*, perfis(nome, nome_artistico, email)")
        .order("created_at", desc=True)
        .limit(100)
    )
    if status:
        query = query.eq("status", status)
    resp = query.execute()
    return jsonify(resp.data or []), 200


@admin_bp.route("/saques/<saque_id>/aprovar", methods=["POST"])
@require_auth
def aprovar_saque_admin(saque_id):
    _check_admin()
    data = request.get_json(force=True, silent=True) or {}
    acao = data.get("acao")  # pago | processando | rejeitado
    motivo = data.get("motivo")

    if acao not in ("pago", "processando", "rejeitado"):
        abort(422, description="Acao invalida.")

    sb = get_supabase()
    try:
        sb.rpc("aprovar_saque", {
            "p_saque_id": saque_id,
            "p_acao":     acao,
            "p_motivo":   motivo,
        }).execute()
    except Exception as e:
        abort(500, description=f"Erro ao aprovar saque: {str(e)}")

    return jsonify({"ok": True, "acao": acao}), 200
