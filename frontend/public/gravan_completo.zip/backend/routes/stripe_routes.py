"""
Routes: /api/stripe — Stripe Checkout integration

CORREÇÕES DE VULNERABILIDADES:
- #6 (ALTA): Webhook validation melhorada
- #14 (MÉDIA): Audit logging de transações
"""
import os
import stripe
import json
import logging
from flask import Blueprint, request, jsonify, g, abort
from middleware.auth import require_auth
from db.supabase_client import get_supabase
from services.finance import calcular_split
from utils.audit import AuditLogger
from app import limiter

logger = logging.getLogger('pitchme.stripe')

stripe_bp = Blueprint("stripe", __name__)
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY")
WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
FRONTEND_URL   = os.environ.get("FRONTEND_URL", "http://localhost:5173")

# Métodos Pitch.me -> Stripe (PIX exige ativação no Stripe BR; usamos card por padrão)
METODO_TO_STRIPE = {
    "pix":     ["card"],   # fallback: card (PIX precisa ativação manual no painel Stripe)
    "credito": ["card"],
    "debito":  ["card"],
    "boleto":  ["boleto"],
}


@stripe_bp.route("/checkout", methods=["POST"])
@require_auth
@limiter.limit("20 per hour")
def criar_checkout():
    if not stripe.api_key:
        abort(500, description="Stripe não configurado: STRIPE_SECRET_KEY ausente no .env")

    data = request.get_json(force=True, silent=True) or {}
    obra_id = data.get("obra_id")
    metodo  = data.get("metodo", "credito")

    # Validacao: comprador precisa ter cadastro completo
    sb_check = get_supabase()
    perfil_check = sb_check.table("perfis").select("cadastro_completo, role").eq("id", g.user.id).single().execute()
    if not perfil_check.data:
        abort(404, description="Perfil nao encontrado.")
    if not perfil_check.data.get("cadastro_completo"):
        abort(422, description="Complete seu cadastro (CPF, RG, endereco) antes de comprar.")

    # Proteção anti-auto-compra: titular não pode comprar sua propria obra
    obra_check = sb_check.table("obras").select("titular_id").eq("id", obra_id).single().execute()
    if obra_check.data and obra_check.data.get("titular_id") == g.user.id:
        abort(422, description="Voce nao pode comprar uma obra de sua propria autoria.")

    if not obra_id:
        abort(422, description="obra_id obrigatório.")
    if metodo not in METODO_TO_STRIPE:
        abort(422, description=f"Método inválido: {metodo}")

    sb = get_supabase()

    # Busca a obra
    obra_resp = (
        sb.table("obras")
        .select("id, nome, preco_cents, status, titular_id")
        .eq("id", obra_id)
        .single()
        .execute()
    )
    if not obra_resp.data:
        abort(404, description="Obra não encontrada.")
    obra = obra_resp.data
    if obra.get("status") != "publicada":
        abort(422, description="Obra não está publicada.")
    if not obra.get("preco_cents") or obra["preco_cents"] < 100:
        abort(422, description="Obra com preço inválido.")

    # Nome do compositor (separado pra evitar erro de join nulo)
    titular = sb.table("perfis").select("nome").eq("id", obra["titular_id"]).single().execute()
    titular_nome = (titular.data or {}).get("nome", "Pitch.me")

    # Coautorias para split
    coaut = sb.table("coautorias").select("perfil_id, share_pct").eq("obra_id", obra_id).execute()
    coautorias = coaut.data or []
    if not coautorias:
        # Caso a obra não tenha coautoria registrada, cria automática 100% pro titular
        coautorias = [{"perfil_id": obra["titular_id"], "share_pct": 100}]

    try:
        split = calcular_split(obra["preco_cents"], coautorias)
    except ValueError as e:
        abort(422, description=str(e))

    # Cria a sessão Stripe
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=METODO_TO_STRIPE[metodo],
            mode="payment",
            line_items=[{
                "price_data": {
                    "currency": "brl",
                    "product_data": {
                        "name": f"Licença: {obra['nome']}",
                        "description": f"Composição musical de {titular_nome}",
                    },
                    "unit_amount": obra["preco_cents"],
                },
                "quantity": 1,
            }],
            customer_email=g.user.email,
            success_url=f"{FRONTEND_URL}/pagamento/sucesso?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{FRONTEND_URL}/pagamento/cancelado?session_id={{CHECKOUT_SESSION_ID}}",
            metadata={
                "obra_id":      obra_id,
                "comprador_id": g.user.id,
                "metodo":       metodo,
            },
        )
    except stripe.error.StripeError as e:
        msg = e.user_message or str(e)
        abort(500, description=f"Erro Stripe: {msg}")
    except Exception as e:
        abort(500, description=f"Erro ao criar checkout: {str(e)}")

    # Salva transação como pendente
    try:
        sb.table("transacoes").insert({
            "obra_id":           obra_id,
            "comprador_id":      g.user.id,
            "valor_cents":       split.valor_cents,
            "plataforma_cents":  split.plataforma_cents,
            "liquido_cents":     split.liquido_cents,
            "metodo":            metodo,
            "status":            "pendente",
            "stripe_session_id": session.id,
            "stripe_url":        session.url,
        }).execute()
    except Exception as e:
        # Se a inserção falhar, ainda retorna a URL pra não bloquear o usuário
        print(f"[WARN] Falha ao salvar transação: {e}")

    return jsonify({
        "checkout_url": session.url,
        "session_id":   session.id,
    }), 200


@stripe_bp.route("/webhook", methods=["POST"])
def webhook():
    """
    Webhook do Stripe para confirmar pagamentos.
    
    CORREÇÃO VULNERABILIDADE #6 (ALTA): Validação melhorada de webhook.
    - SEMPRE exige WEBHOOK_SECRET em produção
    - Em dev, valida origem e exige localhost
    """
    payload   = request.data
    signature = request.headers.get("Stripe-Signature", "")
    
    # CORREÇÃO #6 (ALTA): Webhook validation melhorada
    is_dev = os.environ.get("FLASK_ENV", "development") == "development"
    is_prod = not is_dev

    try:
        # Em PRODUÇÃO: SEMPRE exige webhook secret
        if is_prod and not WEBHOOK_SECRET:
            logger.error("PRODUÇÃO sem STRIPE_WEBHOOK_SECRET configurado!")
            abort(500, description="Webhook não configurado corretamente.")
        
        if WEBHOOK_SECRET:
            # Validação completa com assinatura HMAC
            event = stripe.Webhook.construct_event(payload, signature, WEBHOOK_SECRET)
            event_type = event["type"]
            obj = event["data"]["object"]
            logger.info(f"Webhook validado: {event_type}")
            
        elif is_dev:
            # Dev sem secret: valida origem local APENAS
            if request.remote_addr not in ("127.0.0.1", "::1", "localhost"):
                logger.warning(f"Webhook de origem não-local rejeitado: {request.remote_addr}")
                abort(403, description="Webhook só aceito do localhost em dev.")
            
            event = json.loads(payload)
            event_type = event.get("type", "")
            obj = event.get("data", {}).get("object", {})
            logger.warning(f"Webhook DEV sem validação HMAC: {event_type}")
        else:
            abort(500, description="Configuração de webhook inválida.")
            
    except stripe.error.SignatureVerificationError as e:
        logger.error(f"Assinatura inválida: {e}")
        abort(400, description="Assinatura inválida do webhook.")
    except json.JSONDecodeError:
        logger.error("Payload JSON inválido")
        abort(400, description="Payload inválido.")
    except Exception as e:
        logger.error(f"Erro ao processar webhook: {e}")
        abort(400, description="Erro ao processar webhook.")

    sb = get_supabase()

    # Processa eventos
    if event_type == "checkout.session.completed":
        session_id     = obj.get("id") if isinstance(obj, dict) else obj.id
        payment_intent = obj.get("payment_intent") if isinstance(obj, dict) else obj.payment_intent
        
        # Atualiza transação
        result = sb.table("transacoes").update({
            "status":                "confirmada",
            "stripe_payment_intent": payment_intent,
            "confirmed_at":          "now()",
        }).eq("stripe_session_id", session_id).execute()
        
        # CORREÇÃO #14 (MÉDIA): Audit log
        if result.data:
            trans = result.data[0]
            AuditLogger.log_compra(
                trans["id"], 
                trans["obra_id"], 
                trans["valor_cents"]
            )

    elif event_type in ("checkout.session.expired", "payment_intent.payment_failed"):
        session_id = obj.get("id") if isinstance(obj, dict) else obj.id
        sb.table("transacoes").update({
            "status": "cancelada",
        }).eq("stripe_session_id", session_id).execute()

    return jsonify({"received": True}), 200


@stripe_bp.route("/sucesso/<session_id>", methods=["GET"])
@require_auth
def verificar_sucesso(session_id):
    if not stripe.api_key:
        abort(500, description="Stripe não configurado.")

    try:
        session = stripe.checkout.Session.retrieve(session_id)
    except stripe.error.StripeError as e:
        abort(404, description=f"Sessão não encontrada: {str(e)}")

    sb = get_supabase()
    trans = (
        sb.table("transacoes")
        .select("id, status, valor_cents, obras(nome)")
        .eq("stripe_session_id", session_id)
        .single()
        .execute()
    )
    if not trans.data:
        abort(404, description="Transação não encontrada.")

    # Confirma se Stripe pagou mas o webhook não rodou
    if session.payment_status == "paid" and trans.data["status"] == "pendente":
        sb.table("transacoes").update({
            "status":                "confirmada",
            "stripe_payment_intent": session.payment_intent,
            "confirmed_at":          "now()",
        }).eq("stripe_session_id", session_id).execute()
        trans.data["status"] = "confirmada"

    return jsonify({
        "transacao":     trans.data,
        "stripe_status": session.payment_status,
        "obra_nome":     trans.data.get("obras", {}).get("nome") if trans.data.get("obras") else None,
    }), 200
