"""
Routes: /api/paypal — PayPal integration

Endpoints para criar e executar pagamentos via PayPal.
"""
from flask import Blueprint, request, jsonify, g, abort
from middleware.auth import require_auth
from db.supabase_client import get_supabase
from services.paypal_service import PayPalService
from services.finance import calcular_split
from utils.audit import AuditLogger
from app import limiter
import os

paypal_bp = Blueprint("paypal", __name__)

FRONTEND_URL = os.environ.get("FRONTEND_URL", "https://defense-first-app.cluster-0.preview.emergentcf.cloud")


@paypal_bp.route("/create-payment", methods=["POST"])
@require_auth
@limiter.limit("5 per minute")
def create_payment():
    """
    Cria um pagamento PayPal para compra de obra.
    
    Body JSON:
        obra_id: UUID da obra
    
    Returns:
        approval_url: URL para redirecionar usuário ao PayPal
        payment_id: ID do pagamento para tracking
    """
    data = request.get_json(force=True, silent=True) or {}
    obra_id = data.get("obra_id")
    
    if not obra_id:
        abort(422, description="obra_id é obrigatório.")
    
    sb = get_supabase()
    
    # Busca obra
    obra_resp = sb.table("obras").select("*").eq("id", obra_id).single().execute()
    if not obra_resp.data:
        abort(404, description="Obra não encontrada.")
    
    obra = obra_resp.data
    
    # Verifica se obra está disponível
    if obra.get("status") != "publicada":
        abort(422, description="Obra não disponível para compra.")
    
    # Anti-auto-compra: impede titular comprar própria obra
    if obra.get("titular_id") == g.user.id:
        abort(422, description="Você não pode comprar sua própria obra.")
    
    # Verifica se já comprou
    compra_existente = sb.table("transacoes").select("id").eq("obra_id", obra_id).eq("comprador_id", g.user.id).eq("status", "confirmada").execute()
    if compra_existente.data:
        abort(409, description="Você já possui esta obra.")
    
    preco_cents = obra.get("preco_cents")
    
    # URLs de retorno
    return_url = f"{FRONTEND_URL}/pagamento/paypal/sucesso"
    cancel_url = f"{FRONTEND_URL}/pagamento/paypal/cancelado"
    
    # Cria pagamento no PayPal
    result = PayPalService.create_payment(
        amount_cents=preco_cents,
        obra_id=obra_id,
        comprador_id=g.user.id,
        return_url=return_url,
        cancel_url=cancel_url
    )
    
    if not result.get("success"):
        abort(500, description=f"Erro ao criar pagamento PayPal: {result.get('error')}")
    
    # Cria transação pendente no banco
    transacao = sb.table("transacoes").insert({
        "obra_id": obra_id,
        "comprador_id": g.user.id,
        "valor_cents": preco_cents,
        "metodo_pagamento": "paypal",
        "status": "pendente",
        "paypal_payment_id": result["payment_id"]
    }).execute()
    
    return jsonify({
        "approval_url": result["approval_url"],
        "payment_id": result["payment_id"],
        "transacao_id": transacao.data[0]["id"]
    }), 200


@paypal_bp.route("/execute-payment", methods=["POST"])
@require_auth
@limiter.limit("10 per minute")
def execute_payment():
    """
    Executa (confirma) um pagamento PayPal após aprovação do usuário.
    
    Query Params (vindos da URL de retorno do PayPal):
        paymentId: ID do pagamento
        PayerID: ID do pagador
    
    Returns:
        success: true/false
        transacao: dados da transação confirmada
    """
    payment_id = request.args.get("paymentId") or request.json.get("paymentId")
    payer_id = request.args.get("PayerID") or request.json.get("PayerID")
    
    if not payment_id or not payer_id:
        abort(422, description="paymentId e PayerID são obrigatórios.")
    
    sb = get_supabase()
    
    # Busca transação pendente
    trans_resp = sb.table("transacoes").select("*").eq("paypal_payment_id", payment_id).eq("comprador_id", g.user.id).single().execute()
    if not trans_resp.data:
        abort(404, description="Transação não encontrada.")
    
    transacao = trans_resp.data
    
    if transacao.get("status") == "confirmada":
        abort(409, description="Transação já foi confirmada.")
    
    # Executa pagamento no PayPal
    result = PayPalService.execute_payment(payment_id, payer_id)
    
    if not result.get("success"):
        # Falha na execução
        sb.table("transacoes").update({
            "status": "cancelada"
        }).eq("id", transacao["id"]).execute()
        
        abort(500, description=f"Erro ao executar pagamento: {result.get('error')}")
    
    # Sucesso! Atualiza transação
    sb.table("transacoes").update({
        "status": "confirmada",
        "payer_email": result.get("payer_email"),
        "confirmed_at": "now()"
    }).eq("id", transacao["id"]).execute()
    
    # Busca obra para calcular splits
    obra_resp = sb.table("obras").select("*").eq("id", transacao["obra_id"]).single().execute()
    obra = obra_resp.data
    
    # Calcula e distribui valores
    splits = calcular_split(
        valor_total_cents=transacao["valor_cents"],
        obra_id=obra["id"]
    )
    
    # Credita nas wallets dos compositores
    for split in splits:
        sb.rpc("creditar_wallet", {
            "p_perfil_id": split["perfil_id"],
            "p_valor_cents": split["valor_cents"],
            "p_origem": f"venda_obra_{obra['id']}"
        }).execute()
    
    # Audit log
    AuditLogger.log_compra(transacao["id"], obra["id"], transacao["valor_cents"])
    
    return jsonify({
        "success": True,
        "transacao": transacao,
        "message": "Pagamento confirmado com sucesso!"
    }), 200


@paypal_bp.route("/payment/<payment_id>", methods=["GET"])
@require_auth
def get_payment_status(payment_id: str):
    """
    Consulta status de um pagamento PayPal.
    
    Returns:
        payment_details: detalhes do pagamento
    """
    result = PayPalService.get_payment_details(payment_id)
    
    if not result.get("success"):
        abort(404, description="Pagamento não encontrado.")
    
    return jsonify(result), 200
