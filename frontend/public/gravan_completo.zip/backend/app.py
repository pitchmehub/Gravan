"""
Pitch.me — API Flask com hardening completo de segurança.

CORREÇÕES DE VULNERABILIDADES IMPLEMENTADAS:
- #5 (ALTA): CSRF Protection via Flask-WTF
- #8 (ALTA): Secure session configuration  
- #11 (MÉDIA): Content Security Policy headers
- #13 (MÉDIA): Rate limiting otimizado
- #19 (BAIXA): SameSite cookie configuration
"""
import os
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect
from dotenv import load_dotenv

load_dotenv()

# Rate limiter - tenta Redis primeiro, fallback pra memória
REDIS_URL = os.getenv("REDIS_URL", "memory://")
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["600 per minute", "10000 per hour"],
    storage_uri=REDIS_URL,
)

# CSRF Protection (vulnerabilidade #5)
csrf = CSRFProtect()


def create_app() -> Flask:
    app = Flask(__name__)
    
    # ═══════════════════════════════════════════════════════════
    # SESSION CONFIGURATION (Vulnerabilidade #8 - ALTA)
    # ═══════════════════════════════════════════════════════════
    app.secret_key = os.environ["FLASK_SECRET_KEY"]
    app.config.update(
        SESSION_COOKIE_SECURE=request.is_secure if request else True,  # HTTPS only em prod
        SESSION_COOKIE_HTTPONLY=True,  # Bloqueia acesso via JavaScript
        SESSION_COOKIE_SAMESITE='Lax',  # Proteção CSRF adicional (vuln #19)
        PERMANENT_SESSION_LIFETIME=3600,  # 1 hora
        SESSION_COOKIE_NAME='pitchme_session',
    )

    # ═══════════════════════════════════════════════════════════
    # CORS CONFIGURATION
    # ═══════════════════════════════════════════════════════════
    allowed = os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",")
    allowed = [o.strip() for o in allowed if o.strip()]
    CORS(
        app,
        resources={r"/api/*": {"origins": allowed}},
        supports_credentials=True,  # Permite cookies
        max_age=3600,
    )

    # ═══════════════════════════════════════════════════════════
    # SECURITY CONFIGURATIONS
    # ═══════════════════════════════════════════════════════════
    app.config["MAX_CONTENT_LENGTH"] = 11 * 1024 * 1024  # 10MB + margem
    
    # CSRF Protection (vulnerabilidade #5 - ALTA)
    # Exempta rotas de webhook que usam validação externa
    csrf.init_app(app)
    app.config['WTF_CSRF_CHECK_DEFAULT'] = False  # Controle manual por rota
    
    # Rate Limiter (vulnerabilidade #13 - MÉDIA otimizada)
    limiter.init_app(app)

    # ═══════════════════════════════════════════════════════════
    # SECURITY HEADERS (Vulnerabilidades #7, #11)
    # ═══════════════════════════════════════════════════════════
    @app.after_request
    def add_security_headers(response):
        # Básicos
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        
        # HSTS (HTTPS only)
        if request.is_secure:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
        
        # ─────────────────────────────────────────────────────────
        # CSP (Content Security Policy) - Vulnerabilidade #11 (MÉDIA)
        # ─────────────────────────────────────────────────────────
        csp_directives = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com",  # Stripe precisa
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
            "font-src 'self' https://fonts.gstatic.com",
            "img-src 'self' data: https: blob:",
            "media-src 'self' blob: https://*.supabase.co",  # Storage Supabase
            "connect-src 'self' https://*.supabase.co https://api.stripe.com",
            "frame-src 'self' https://js.stripe.com",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self'",
            "frame-ancestors 'none'",
        ]
        response.headers["Content-Security-Policy"] = "; ".join(csp_directives)
        
        return response

    # ═══════════════════════════════════════════════════════════
    # BLUEPRINTS
    # ═══════════════════════════════════════════════════════════
    # Imports absolutos para compatibilidade com gunicorn
    import routes.obras as obras_module
    import routes.transacoes as transacoes_module
    import routes.perfis as perfis_module
    import routes.catalogo as catalogo_module
    import routes.admin as admin_module
    import routes.stripe_routes as stripe_module
    import routes.paypal_routes as paypal_module
    import routes.contato as contato_module
    import routes.download as download_module
    
    obras_bp = obras_module.obras_bp
    transacoes_bp = transacoes_module.transacoes_bp
    perfis_bp = perfis_module.perfis_bp
    catalogo_bp = catalogo_module.catalogo_bp
    admin_bp = admin_module.admin_bp
    stripe_bp = stripe_module.stripe_bp
    paypal_bp = paypal_module.paypal_bp
    contato_bp = contato_module.contato_bp
    download_bp = download_module.download_bp

    app.register_blueprint(obras_bp, url_prefix="/api/obras")
    app.register_blueprint(transacoes_bp, url_prefix="/api/transacoes")
    app.register_blueprint(perfis_bp, url_prefix="/api/perfis")
    app.register_blueprint(catalogo_bp, url_prefix="/api/catalogo")
    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(stripe_bp, url_prefix="/api/stripe")
    app.register_blueprint(paypal_bp, url_prefix="/api/paypal")
    app.register_blueprint(contato_bp, url_prefix="/api/contato")
    app.register_blueprint(download_bp, url_prefix="/api")

    # ═══════════════════════════════════════════════════════════
    # ERROR HANDLERS (Vulnerabilidade #7 - logs seguros)
    # ═══════════════════════════════════════════════════════════
    import utils.errors as errors_module
    errors_module.register_error_handlers(app)

    @app.errorhandler(429)
    def ratelimit_handler(e):
        return jsonify({"error": "Muitas requisições. Aguarde um momento."}), 429

    # ═══════════════════════════════════════════════════════════
    # HEALTH CHECK
    # ═══════════════════════════════════════════════════════════
    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify({"status": "healthy", "version": "2.0-secure"}), 200

    return app
