"""
Sistema de Audit Logging para rastreabilidade de ações sensíveis.
Correção de vulnerabilidade #14 (MÉDIA): Falta de audit logging.
"""
import json
from datetime import datetime
from flask import g, request
from db.supabase_client import get_supabase

class AuditLogger:
    """Logger de auditoria para ações críticas."""
    
    @staticmethod
    def log(action: str, resource_type: str, resource_id: str = None, details: dict = None):
        """
        Registra ação de auditoria no banco.
        
        Args:
            action: Ação realizada (criar, atualizar, deletar, comprar, etc)
            resource_type: Tipo de recurso (obra, transacao, perfil, etc)
            resource_id: ID do recurso afetado
            details: Detalhes adicionais em JSON
        """
        try:
            user_id = getattr(g, 'user', None)
            user_id = user_id.id if user_id else None
            
            log_entry = {
                "user_id": user_id,
                "action": action,
                "resource_type": resource_type,
                "resource_id": resource_id,
                "details": details or {},
                "ip_address": request.remote_addr if request else None,
                "user_agent": request.headers.get('User-Agent', '')[:500] if request else None,
                "timestamp": datetime.utcnow().isoformat(),
            }
            
            # Salva no Supabase (assumindo tabela audit_logs)
            sb = get_supabase()
            sb.table("audit_logs").insert(log_entry).execute()
            
        except Exception as e:
            # Não falha a request se audit log falhar
            print(f"[WARN] Audit log failed: {e}")
    
    @staticmethod
    def log_obra_criada(obra_id: str, nome: str):
        AuditLogger.log("criar_obra", "obra", obra_id, {"nome": nome})
    
    @staticmethod
    def log_obra_deletada(obra_id: str):
        AuditLogger.log("deletar_obra", "obra", obra_id)
    
    @staticmethod
    def log_compra(transacao_id: str, obra_id: str, valor_cents: int):
        AuditLogger.log("comprar_obra", "transacao", transacao_id, {
            "obra_id": obra_id,
            "valor_cents": valor_cents
        })
    
    @staticmethod
    def log_saque(saque_id: str, valor_cents: int):
        AuditLogger.log("solicitar_saque", "saque", saque_id, {
            "valor_cents": valor_cents
        })
    
    @staticmethod
    def log_login_attempt(email: str, success: bool):
        """Para detecção de brute force (vulnerabilidade #18)."""
        AuditLogger.log(
            "login_attempt" if success else "login_failed",
            "auth",
            None,
            {"email": email, "success": success}
        )
