"""
Motor Financeiro do Pitch.me.

Todos os calculos sao realizados EXCLUSIVAMENTE aqui, no servidor.

Estrutura de receita:
  Valor bruto da venda
  - 20% Taxa de intermediacao -> plataforma
  - 80% Liquido               -> compositores (conforme share_pct)
"""
from decimal import Decimal, ROUND_DOWN
from dataclasses import dataclass

PLATFORM_RATE = Decimal("0.20")  # 20% plataforma
COMPOSER_RATE = Decimal("0.80")  # 80% compositores


@dataclass
class SplitResult:
    valor_cents:         int
    plataforma_cents:    int
    liquido_cents:       int
    intermediacao_cents: int
    edicao_cents:        int
    payouts: list


def calcular_split(valor_cents: int, coautorias: list) -> SplitResult:
    if valor_cents <= 0:
        raise ValueError("Valor da venda deve ser positivo.")

    total_pct = sum(Decimal(str(c["share_pct"])) for c in coautorias)
    if total_pct != Decimal("100"):
        raise ValueError(
            f"A soma dos splits deve ser exatamente 100%. Recebido: {total_pct}%"
        )

    v = Decimal(str(valor_cents))
    plataforma = (v * PLATFORM_RATE).to_integral_value(ROUND_DOWN)
    liquido    = v - plataforma

    payouts = []
    distribuido = Decimal("0")

    for i, coautoria in enumerate(coautorias):
        pct = Decimal(str(coautoria["share_pct"]))
        if i == len(coautorias) - 1:
            valor_compositor = int(liquido - distribuido)
        else:
            valor_compositor = int(
                (liquido * pct / Decimal("100")).to_integral_value(ROUND_DOWN)
            )
            distribuido += Decimal(str(valor_compositor))

        payouts.append({
            "perfil_id":   coautoria["perfil_id"],
            "valor_cents": valor_compositor,
            "share_pct":   float(pct),
        })

    return SplitResult(
        valor_cents=valor_cents,
        plataforma_cents=int(plataforma),
        liquido_cents=int(liquido),
        intermediacao_cents=int(plataforma),
        edicao_cents=0,
        payouts=payouts,
    )


def validar_preco(preco_cents: int) -> None:
    if not isinstance(preco_cents, int) or preco_cents < 100:
        raise ValueError("Preco minimo: R$ 1,00 (100 centavos).")
